// /后端服务/routes/auth.js

const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const pool = require('../db');
const axios = require('axios');
const {
    JWT_SECRET,
    LINUX_DO_CLIENT_ID,
    LINUX_DO_CLIENT_SECRET,
    LINUX_DO_REDIRECT_URI,
    LINUX_DO_AUTHORIZE_URL,
    LINUX_DO_TOKEN_URL,
    LINUX_DO_USER_INFO_URL
} = require('../config');
const router = express.Router();
const authenticateToken = require('../authMiddleware');

// --- 用户认证路由 ---

/**
 * @route   POST /api/auth/register
 * @desc    注册新用户 (支持用户名或邮箱)
 * @access  Public
 */
router.post('/register', async (req, res) => {
    try {
        const { username, email, password } = req.body;

        // 1. 基本输入验证
        if ((!username && !email) || !password || password.length < 6) {
            return res.status(400).json({ message: '用户名或邮箱至少提供一项，且密码至少为6位。' });
        }

        // 2. 检查用户名和邮箱是否已被注册
        if (username) {
            const [users] = await pool.query('SELECT id FROM users WHERE username = ?', [username]);
            if (users.length > 0) {
                return res.status(409).json({ message: '该用户名已被注册。' });
            }
        }
        if (email) {
            const [users] = await pool.query('SELECT id FROM users WHERE email = ?', [email]);
            if (users.length > 0) {
                return res.status(409).json({ message: '该邮箱已被注册。' });
            }
        }

        // 3. 哈希密码
        const salt = await bcrypt.genSalt(10);
        const password_hash = await bcrypt.hash(password, salt);

        // 4. 存入数据库
        const [result] = await pool.query(
            'INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)',
            [username || null, email || null, password_hash]
        );
        res.status(201).json({ message: '注册成功！', userId: result.insertId });

    } catch (error) {
        // 捕捉唯一的约束冲突错误
        if (error.code === 'ER_DUP_ENTRY') {
            return res.status(409).json({ message: '用户名或邮箱已被注册。' });
        }
        console.error('注册失败:', error);
        res.status(500).json({ message: '服务器内部错误。' });
    }
});

/**
 * @route   POST /api/auth/login
 * @desc    用户登录 (支持用户名或邮箱)
 * @access  Public
 */
router.post('/login', async (req, res) => {
    try {
        const { identifier, password } = req.body; // identifier 可以是 username 或 email
        if (!identifier || !password) {
            return res.status(400).json({ message: '请输入用户名/邮箱和密码。' });
        }

        // 1. 查找用户
        const [users] = await pool.query('SELECT * FROM users WHERE username = ? OR email = ?', [identifier, identifier]);
        const user = users[0];
        if (!user || !user.password_hash) { // 如果用户不存在或没有设置密码（例如OAuth用户首次登录）
            return res.status(401).json({ message: '用户名/邮箱或密码错误。' });
        }

        // 2. 验证密码
        const isMatch = await bcrypt.compare(password, user.password_hash);
        if (!isMatch) {
            return res.status(401).json({ message: '用户名/邮箱或密码错误。' });
        }

        // 3. 生成 JWT
        const payload = {
            userId: user.id,
            username: user.username,
            email: user.email
        };
        const token = jwt.sign(payload, JWT_SECRET, { expiresIn: '1d' });
        res.json({ message: '登录成功！', token });

    } catch (error) {
        console.error('登录失败:', error);
        res.status(500).json({ message: '服务器内部错误。' });
    }
});


// --- OAuth 2.0 (Linux.do) 路由 ---

/**
 * @route   GET /api/auth/linuxdo
 * @desc    重定向到 Linux.do 的授权页面
 * @access  Public
 */
router.get('/auth/linuxdo', (req, res) => {
    const params = new URLSearchParams({
        client_id: LINUX_DO_CLIENT_ID,
        redirect_uri: LINUX_DO_REDIRECT_URI,
        response_type: 'code',
        scope: 'read',
    });
    res.redirect(`${LINUX_DO_AUTHORIZE_URL}?${params.toString()}`);
});

/**
 * @route   GET /api/auth/linuxdo/callback
 * @desc    处理 Linux.do 的回调，完成 OAuth 流程
 * @access  Public
 */
router.get('/auth/linuxdo/callback', async (req, res) => {
    const { code } = req.query;

    if (!code) {
        return res.status(400).json({ message: 'Authorization code is missing.' });
    }

    try {
        // 1. 使用授权码换取 access token
        const tokenResponse = await axios.post(LINUX_DO_TOKEN_URL, new URLSearchParams({
            grant_type: 'authorization_code',
            code: code,
            redirect_uri: LINUX_DO_REDIRECT_URI,
            client_id: LINUX_DO_CLIENT_ID,
            client_secret: LINUX_DO_CLIENT_SECRET,
        }), {
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
        });
        const { access_token } = tokenResponse.data;

        // 2. 使用 access token 获取用户信息
        const userResponse = await axios.get(LINUX_DO_USER_INFO_URL, {
            headers: { 'Authorization': `Bearer ${access_token}` }
        });
        const { username, email } = userResponse.data;

        // 3. 在本地数据库中查找或创建用户
        let [users] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
        let user = users[0];

        if (!user) {
            // 如果用户不存在，则创建新用户
            const [result] = await pool.query('INSERT INTO users (username, email) VALUES (?, ?)', [username, email]);
            [users] = await pool.query('SELECT * FROM users WHERE id = ?', [result.insertId]);
            user = users[0];
        }

        // 4. 为该用户创建 JWT
        const payload = {
            userId: user.id,
            username: user.username,
            email: user.email
        };
        const token = jwt.sign(payload, JWT_SECRET, { expiresIn: '1d' });

        // 5. 重定向到前端的回调页面，并将 JWT 作为参数传递
        res.redirect(`https://hb.pandax.it.com/callback.html?token=${token}`);

    } catch (error) {
        console.error('Linux.do OAuth 认证失败:', error.response ? error.response.data : error.message);
        res.status(500).json({ message: '服务器内部错误。' });
    }
});

// --- 用户信息管理路由 ---

/**
 * @route   GET /api/me
 * @desc    获取当前登录用户的信息
 * @access  Private (需要认证)
 */
router.get('/me', authenticateToken, async (req, res) => {
    try {
        // req.user 来自于 authenticateToken 中间件解码的 JWT
        const [users] = await pool.query('SELECT id, email, username, password_hash IS NOT NULL AS has_password FROM users WHERE id = ?', [req.user.userId]);
        const user = users[0];

        if (!user) {
            return res.status(404).json({ message: '未找到用户。' });
        }
        // 将 has_password 转换为布尔值
        user.has_password = Boolean(user.has_password);
        res.json(user);
    } catch (error) {
        console.error('获取用户资料失败:', error);
        res.status(500).json({ message: '服务器内部错误。' });
    }
});

/**
 * @route   PUT /api/me/profile
 * @desc    更新用户信息 (用户名或邮箱)
 * @access  Private
 */
router.put('/me/profile', authenticateToken, async (req, res) => {
    const { username, email } = req.body;
    const userId = req.user.userId;

    if (!username && !email) {
        return res.status(400).json({ message: '至少提供用户名或邮箱进行更新。' });
    }

    try {
        const updates = {};
        if (username) updates.username = username;
        if (email) updates.email = email;

        await pool.query('UPDATE users SET ? WHERE id = ?', [updates, userId]);

        const [updatedUsers] = await pool.query('SELECT id, email, username FROM users WHERE id = ?', [userId]);

        res.json({ message: '个人资料更新成功！', user: updatedUsers[0] });

    } catch (error) {
        if (error.code === 'ER_DUP_ENTRY') {
            return res.status(409).json({ message: '用户名或邮箱已被其他用户占用。' });
        }
        console.error('更新个人资料失败:', error);
        res.status(500).json({ message: '服务器内部错误。' });
    }
});


/**
 * @route   POST /api/change-password
 * @desc    更改用户密码
 * @access  Private (需要认证)
 */
router.post('/change-password', authenticateToken, async (req, res) => {
    const { oldPassword, newPassword } = req.body;
    const userId = req.user.userId;

    if (!oldPassword || !newPassword || newPassword.length < 6) {
        return res.status(400).json({ message: '密码格式不正确 (新密码至少6位)。' });
    }

    try {
        // 1. 获取当前用户的密码哈希
        const [users] = await pool.query('SELECT password_hash FROM users WHERE id = ?', [userId]);
        const user = users[0];

        // 如果找不到用户或用户没有密码（例如，通过OAuth注册），则拒绝操作
        if (!user || !user.password_hash) {
            return res.status(403).json({ message: '此账户不支持密码更改。' });
        }

        // 2. 验证旧密码
        const isMatch = await bcrypt.compare(oldPassword, user.password_hash);
        if (!isMatch) {
            return res.status(401).json({ message: '旧密码错误。' });
        }

        // 3. 哈希并更新新密码
        const salt = await bcrypt.genSalt(10);
        const newPasswordHash = await bcrypt.hash(newPassword, salt);
        await pool.query('UPDATE users SET password_hash = ? WHERE id = ?', [newPasswordHash, userId]);

        res.json({ message: '密码更改成功！' });

    } catch (error) {
        console.error('更改密码失败:', error);
        res.status(500).json({ message: '服务器内部错误。' });
    }
});

module.exports = router;
