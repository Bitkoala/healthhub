// /后端服务/routes/sex.js

const express = require('express');
const pool = require('../db');
const authenticateToken = require('../authMiddleware');
const router = express.Router();

// --- 性生活记录路由 ---

/**
 * @route   GET /api/sex
 * @desc    获取用户所有的性生活记录
 * @access  Private
 */
router.get('/', authenticateToken, async (req, res) => {
    const userId = req.user.userId;
    try {
        const [logs] = await pool.query('SELECT log_date FROM sex_logs WHERE user_id = ? ORDER BY log_date DESC', [userId]);
        // 只返回日期数组以节省带宽
        res.json(logs.map(log => log.log_date.toISOString().split('T')[0]));
    } catch (error) {
        console.error('获取性生活记录失败:', error);
        res.status(500).json({ message: '服务器内部错误。' });
    }
});

/**
 * @route   POST /api/sex
 * @desc    记录一次新的性生活
 * @access  Private
 */
router.post('/', authenticateToken, async (req, res) => {
    const { log_date } = req.body;
    const userId = req.user.userId;

    if (!log_date) {
        return res.status(400).json({ message: '日期是必填项。' });
    }

    try {
        // 使用 INSERT IGNORE 来避免因唯一键冲突（同一天重复记录）而报错
        const [result] = await pool.query(
            'INSERT IGNORE INTO sex_logs (user_id, log_date) VALUES (?, ?)',
            [userId, log_date]
        );

        if (result.affectedRows === 0) {
            // 如果没有行被插入，说明记录已存在
            return res.status(200).json({ message: '记录已存在。' });
        }
        
        res.status(201).json({ message: '记录成功！' });
    } catch (error) {
        console.error('记录性生活失败:', error);
        res.status(500).json({ message: '服务器内部错误。' });
    }
});

/**
 * @route   DELETE /api/sex/:date
 * @desc    删除某一天的性生活记录
 * @access  Private
 */
router.delete('/:date', authenticateToken, async (req, res) => {
    const { date } = req.params;
    const userId = req.user.userId;

    try {
        const [result] = await pool.query('DELETE FROM sex_logs WHERE user_id = ? AND log_date = ?', [userId, date]);

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: '未找到相关记录。' });
        }

        res.json({ message: '记录删除成功！' });
    } catch (error) {
        console.error('删除性生活记录失败:', error);
        res.status(500).json({ message: '服务器内部错误。' });
    }
});

module.exports = router;