// /后端服务/authMiddleware.js

const jwt = require('jsonwebtoken');
const { JWT_SECRET } = require('./config');

/**
 * Express 中间件，用于验证 JWT (JSON Web Token)。
 * 从请求头中提取 'Bearer' 类型的 token，并进行验证。
 * @param {object} req - Express 请求对象。
 * @param {object} res - Express 响应对象。
 * @param {function} next - Express next 中间件函数。
 */
const authenticateToken = (req, res, next) => {
    // 从 Authorization 请求头中获取 token
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1]; // 格式: "Bearer TOKEN"

    // 如果没有 token，则返回 401 未授权状态
    if (token == null) {
        return res.sendStatus(401); // Unauthorized
    }

    // 验证 token
    jwt.verify(token, JWT_SECRET, (err, user) => {
        // 如果 token 无效或已过期，则返回 403 禁止访问状态
        if (err) {
            console.error('JWT Verification Error:', err);
            return res.sendStatus(403); // Forbidden
        }
        // 如果 token 有效，将解码后的用户信息附加到请求对象上
        req.user = user;
        // 调用下一个中间件
        next();
    });
};

module.exports = authenticateToken;
    
