// /后端服务/server.js

// 在文件顶部加载 .env 文件中的环境变量
require('dotenv').config(); 

const express = require('express');
const cors = require('cors');

// --- 引入所有模块化路由 ---
const authRoutes = require('./routes/auth');
const medicationRoutes = require('./routes/medications');
const stoolRoutes = require('./routes/stool');
const dailyRoutes = require('./routes/daily');
const memoRoutes = require('./routes/memos');
const financeRoutes = require('./routes/finance');
const exerciseRoutes = require('./routes/exercise');
const periodRoutes = require('./routes/periods');
const sexRoutes = require('./routes/sex');
const weightRoutes = require('./routes/weight'); // 【新增】引入体重管理路由

// --- 初始化 Express 应用 ---
const app = express();

// --- 中间件配置 ---

// 1. CORS (跨源资源共享) 配置
// 定义允许访问此后端服务的域名白名单，支持泛域名
const whitelist = [
  /^https?:\/\/([\w-]+\.)*joru\.email$/,
  /^https?:\/\/([\w-]+\.)*pandax\.it\.com$/,
  /^https?:\/\/([\w-]+\.)*pandax\.mom$/,
  /^https?:\/\/([\w-]+\.)*ucnaming\.net$/,
  /^https?:\/\/([\w-]+\.)*eo\.dnse5\.com$/,
  /^https?:\/\/([\w-]+\.)*eo\.dnse3\.com$/,
];

const corsOptions = {
  origin: (origin, callback) => {
    // 允许来自 Postman、cURL 等非浏览器请求，或满足同源策略的请求
    if (!origin) {
      return callback(null, true);
    }
    // 检查请求源是否匹配白名单中的正则表达式
    const isAllowed = whitelist.some(regex => regex.test(origin));
    if (isAllowed) {
      callback(null, true);
    } else {
      callback(new Error('Not allowed by CORS'));
    }
  },
  optionsSuccessStatus: 200 // 兼容旧版浏览器
};
app.use(cors(corsOptions));

// 2. JSON 解析中间件
// 用于解析请求体中的 JSON 格式数据
app.use(express.json());

// --- 注册路由 ---
// 将不同的 API 路径映射到对应的路由文件
app.use('/api', authRoutes); 
app.use('/api/medications', medicationRoutes); 
app.use('/api/stool-logs', stoolRoutes);
app.use('/api/daily-logs', dailyRoutes);
app.use('/api/memos', memoRoutes);
app.use('/api/finance', financeRoutes);
app.use('/api/exercise', exerciseRoutes);
app.use('/api/periods', periodRoutes);
app.use('/api/sex', sexRoutes);
app.use('/api/weight', weightRoutes); // 【新增】注册体重管理路由

// --- 启动服务器 ---
const PORT = process.env.PORT || 3000; // 从环境变量读取端口，否则默认为 3000
app.listen(PORT, () => {
    console.log(`后端服务已启动 (模块化)，运行在 http://localhost:${PORT}`);
});