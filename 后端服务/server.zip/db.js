// /后端服务/db.js

const mysql = require('mysql2/promise');

/**
 * 数据库配置对象。
 * 所有配置项均从环境变量中读取，以保证安全性。
 * @see https://github.com/mysqljs/mysql#pool-options
 */
const dbConfig = {
    host: process.env.DB_HOST,          // 数据库主机名
    port: process.env.DB_PORT,          // 数据库端口
    user: process.env.DB_USER,          // 数据库用户名
    password: process.env.DB_PASSWORD,  // 数据库密码
    database: process.env.DB_DATABASE,  // 数据库名称
    charset: 'utf8mb4',                 // 设置连接字符集以支持中文
    waitForConnections: true,           // 当连接池耗尽时，是否等待可用连接
    connectionLimit: 10,                // 连接池中最大连接数
    queueLimit: 0                       // 连接请求队列的最大长度（0表示不限制）
};

/**
 * 创建并导出一个 MySQL 连接池。
 * 使用连接池可以更高效地管理数据库连接，避免频繁创建和销毁连接带来的开销。
 */
const pool = mysql.createPool(dbConfig);

/**
 * 强制为每个新连接设置字符集。
 * 这是一个针对顽固环境的强效解决方案，确保通信编码正确。
 */
pool.on('connection', function (connection) {
  connection.query("SET NAMES 'utf8mb4'", (err) => {
    if (err) {
      console.error('Failed to set names to utf8mb4 on new connection', err);
    }
  });
});

module.exports = pool;