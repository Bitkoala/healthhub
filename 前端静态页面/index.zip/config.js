// public/config.js
// 这个文件不会被Vite打包，而是会原样复制到最终的dist目录中。
// 您可以在部署后直接修改这个文件，来改变前端应用的API地址，而无需重新打包。

window.APP_CONFIG = {
  // 请在这里填入您的后端API的实际地址
  API_BASE_URL: 'https://api.pandax.it.com'
};
